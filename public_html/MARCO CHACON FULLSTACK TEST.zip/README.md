Marco Chacon Fullstack Test
============

## Pre-Installed requirements

Before to run the application please install the next 2 node js modules:

__Dispatcher__ 

    npm install httpdispatcher
    
__node-zip__ 

    npm install node-zip

## How to use

To run this test, open a terminal or CMD window, depending of yout OS, then go to folder where the project is contains, if you dont have installed all the requirement modules please install them,  after that run the follow command in your terminal
    
    node server.js
    
When you see the message __Server listening on: http://localhost:8181__, then the server will be running up. So use your preferred web browser and go to any of the next links according the test that you want to run:

__Exercise 1:__   =>   http://localhost:8181/exercise1

__Exercise 2:__   =>   http://localhost:8181/exercise2
